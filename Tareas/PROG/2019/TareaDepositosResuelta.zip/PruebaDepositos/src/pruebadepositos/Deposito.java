/*
 * Clase Deposito.
 */
package pruebadepositos;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

/**
 * Clase que representa un <strong>depósito</strong> de estructura 
 * <strong>cilíndrica</strong>.
 * <p>
 * Los objetos de esta clase contienen atributos que permiten almacenar
 * información sobre:</p>
 * <ul>
 * <li><strong>Altura</strong> del depósito.</li>
 * <li><strong>Radio de la base</strong> del depósito.</li>
 * <li><strong>Caudal de salida</strong> del grifo del depósito.</li>
 * <li><strong>Nivel actual</strong> del depósito.</li>
 * <li><strong>Volumen total</strong> que ha <strong>almacenado</strong>
 * el depósito desde que se creó.</li>
 * <li><strong>Volumen total</strong> que ha <strong>vertido</strong> 
 * el depósito desde que se creó.</li>
 * </ul>
 * <p>
 * La clase también dispone de información general independiente de los objetos
 * concretos que se hayan creado. Es el caso de:</p>
 * <ul>
 * <li><strong>Volumen total</strong> que han <strong>almacenado</strong> todos los
 * depósitos hasta el momento.</li>
 * <li><strong>Volumen total</strong> que han <strong>vertido</strong> todos los
 * depósitos hasta el momento.</li>
 * <li><strong>Número de depósitos totalmente vacíos</strong> en el momento actual.</li>
 * <li><strong>Número de depósitos totalmente llenos</strong> en el momento actual.</li>
 * <li><strong>Número total de depósitos</strong> existentes en el momento actual.</li>
 * </ul>
 *
 * @author profe
 */
public class Deposito {

    // ATRIBUTOS ESTÁTICOS (de clase)
    // ------------------------------
    // Atributos estáticos constantes públicos (rangos y requisitos de los atributos de objeto)
    /**
     * Altura mínima de un depósito, {@value MIN_ALTURA} metros
     */    
    public static final double MIN_ALTURA =  0.20;   // metros 
    /**
     * Altura máxima de un depósito, {@value MAX_ALTURA} metros
     */    
    public static final double MAX_ALTURA = 20.00;   // metros 
    /**
     * Longitud mínima del radio de la base de un depósito, {@value MIN_RADIO} metros
     */    
    public static final double MIN_RADIO  =  0.20;   // metros 
    /**
     * Longitud máxima del radio de la base de un depósito, {@value MAX_RADIO} metros
     */    
    public static final double MAX_RADIO  = 10.00;   // metros 
    /**
     * Relación máxima entre radio y altura, {@value MAX_RATIO_ALTURA_RADIO}.
     * El radio podrá ser como máximo el doble de la altura (o lo que es lo mismo,
     * la altura no podrá ser menor que la mitad del radio).
     */    
    public static final double MAX_RATIO_ALTURA_RADIO = 0.5;
    /**
     * Caudal de salida mínimo del grifo de un depósito, {@value MIN_CAUDAL} litros/segundo
     */    
    public static final double MIN_CAUDAL =  0.001;   // litros/seg 
    /**
     * Caudal de salida máximo del grifo de un depósito, {@value MAX_CAUDAL} litros/segundo
     */    
    public static final double MAX_CAUDAL =  1.000;   // litros/seg 
    /**
     * Valor por omisión (o por defecto) para la altura de un depósito, {@value DEFAULT_ALTURA} metros
     */    
    public static final double DEFAULT_ALTURA =  1.00;   // metros 
    /**
     * Valor por omisión (o por defecto) para el radio de la base de un depósito, {@value DEFAULT_RADIO} metros
     */    
    public static final double DEFAULT_RADIO  =  0.50;   // metros 
    /**
     * Valor por omisión (o por defecto) para el caudal de salida del grifo de un depósito, {@value DEFAULT_CAUDAL_SALIDA} litros/segundo
     */    
    public static final double DEFAULT_CAUDAL_SALIDA =  0.100;   // litros/seg 
    
    // Atributos estáticos variables (privados: "estado" de la clase)
    private static double litrosActualesTotales;           // Cantidad de litros almacenados por todos los depósitos en el momento actual (litros)
    private static double litrosAlmacenadosTotales;        // Histórico de la cantidad de litros almacenados por todos los depósitos hasta el momento actual (litros)
    private static double litrosVertidosTotales;           // Histórico de la cantidad de litros vertidos por todos depósitos hasta el momento actual (litros)
    private static int numDepositosVacios;                 // Cantidad total de depósitos totalmente vacíos.
    private static int numDepositosLlenos;                 // Cantidad total de depósitos totalmente llenos.

    // ATRIBUTOS DE OBJETO (privados)
    // -------------------
    // Atributos de objeto constantes durante la vida del depósito (desde que se crea el objeto)
    // No hace falta declararlas como variables pues no van a cambiar una vez creado el objeto.
    // Representan "características inmutables" de la clase.
    private final double ALTURA;        // Altura del depósito (metros)
    private final double RADIO;         // Radio del depósito (metros)
    private final double CAUDAL_SALIDA; // Caudal de salida del grifo del depósito (litros/seg)
    private final double CAPACIDAD;     // Capacidad del depósito (litros). Calculado como PI*RADIO*RADIO*ALTURA*1000. No es imprescindible, pero simplifica los cálculos.    
    
    // Atributos de objeto variables
    // Representan el "estados" de la clase en un instante dado.
    private double nivel;                  // Nivel del depósito (litros)
    private double litrosAlmacenados;      // Historico de la cantidad de litros totales almacenados por el depósito desde que se fabricó hasta el momento actual (litros)
    private double litrosVertidos;         // Historico de la cantidad de litros totales vertidos por el depósito desde que se fabricó hasta el momento actual (litros)

    // CONSTRUCTORES
    // -------------
    /**
     * Constructor por defecto de la clase. Crea un objeto Deposito con un
     * consumo <strong>altura</strong> de 1 metro, un <strong>radio</strong> de 0.5 metros y un <strong>caudal de salida</strong> de 0.10 litros/seg.
     */
    public Deposito() {
        this(Deposito.DEFAULT_ALTURA, Deposito.DEFAULT_RADIO, Deposito.DEFAULT_CAUDAL_SALIDA);
    }

    /**
     * Constructor con dos parámetros.
     * El <strong>caudal de salida</strong> será por defecto 0.10 litros/seg
     * @param altura <strong>altura</strong> del depósito (metros).
     * @param radio <strong>radio</strong> de la base del depósito (metros). La altura no puede ser menor de la mitad del radio.
     * @throws IllegalArgumentException si alguno de los parámetros está fuera del rango permitido
     * o no cumple los requisitos de geometría (el radio no puede ser superior al doble de la altura).
    */
    public Deposito(double altura, double radio) throws IllegalArgumentException {
        this(altura, radio, Deposito.DEFAULT_CAUDAL_SALIDA);
    }
    
    
    /**
     * Constructor con tres parámetros
     * @param altura <strong>altura</strong> del depósito (metros).
     * @param radio <strong>radio</strong> de la base del depósito (metros). La altura no puede ser menor de la mitad del radio.
     * @param caudalSalida <strong>caudal de salida</strong> del grifo de vertido del depósito (litros/segundo).
     * @throws IllegalArgumentException si alguno de los parámetros está fuera del rango permitido
     * o no cumple los requisitos de geometría (el radio no puede ser superior al doble de la altura).
     */
    public Deposito(double altura, double radio, double caudalSalida) throws IllegalArgumentException {

        // Comprobación de que los parámetros son válidos
        if (altura < Deposito.MIN_ALTURA || altura > Deposito.MAX_ALTURA
                || radio < Deposito.MIN_RADIO || radio > Deposito.MAX_RADIO
                || caudalSalida < Deposito.MIN_CAUDAL || caudalSalida > Deposito.MAX_CAUDAL) {
            // Alguno de los parámetros no estáen el rango permitido
            // No se crea un objeto Deposito.
            // Se lanza una excepción.
            throw new IllegalArgumentException("Error: Parámetros de creación del depósito inválidos. Alguno de ellos no está en el rango permitido.");
        } else if (radio > Deposito.MAX_RATIO_ALTURA_RADIO * altura) {
            // La relación entre Altura y Radio no cumplen los requisitos para la creación de un depósito válido.
            // No se crea un objeto Deposito.
            // Se lanza una excepción.
            throw new IllegalArgumentException("Error: Parámetros de creación del depósito inválidos. No cumplen los requisitos de geometría.");            
        } 
        else {
            // Los valores de los parámetros son válidos, así que construimos el objeto
            
            // Inicialización de los atributos constantes ("características" inmutables del objeto)
            this.ALTURA= altura;
            this.RADIO= radio;
            this.CAUDAL_SALIDA= caudalSalida;
            // Este atributo no es imprescindible, pues depende directamente de radio y altura.
            // Pero va a facilitar mucho el trabajo pues no habrá que volver a hacer este cálculo.
            this.CAPACIDAD= Math.PI*this.RADIO*this.RADIO*this.ALTURA*1000; // Vol cilindro=PI*R^2*h  --- 1 metro cúbico= 1000 litros
            
            // Inicialización de los atributos variables de objeto ("estado" del objeto)
            // (innecesario en Java pues una variable recién declarada se inicia a cero)
            this.nivel= 0;
            this.litrosAlmacenados= 0;
            this.litrosVertidos= 0;

            // Actualización de los atributos varibles de clase (estáticos)
            Deposito.numDepositosVacios++;
         }    
    }

    // Construcotr copia - No había que implementarlo
    /*
     * Constructor copia.
     * Crea un depósito exactamente igual (en estructura y en estado) al que se 
     * pasa como parámetro.
     * @param dep <strong>depósito</strong> que se desea copìar o clonar.
     * @throws IllegalArgumentException si el depósito que se pasa como parámetro es <code>null</code>.
    */
/*    public Deposito (Deposito dep) throws IllegalArgumentException {
        
        // Si el parámetrop es null no se crea ningún depósito y se devuelve una excepción
        if (dep == null)  
            throw new IllegalArgumentException("Error: Parámetro inválido (depósito null)");            
        
        // Si el parámetro es un objeto depósito, se "clonan" sus atributos:
        
        // Valor de los atributos de "estructura" (constantes)
        // "Clonamos" los valores del objeto pasado como parámetro
        this.ALTURA= dep.ALTURA;
        this.RADIO= dep.RADIO;
        this.CAUDAL_SALIDA= dep.CAUDAL_SALIDA;
        this.CAPACIDAD= dep.CAPACIDAD;
        
        // Valor inicial de atributos de "estado" (variables)
        // Podemos copiar los valors del objeto pasado comom parámetro.
        // O bien empezar desde cero.
        // Habría que debatirlo con los "clientes" de la clase (los que vayan a usarla)
        this.nivel= dep.nivel;                          // Es interpretable
        this.litrosAlmacenados= dep.litrosAlmacenados;  // Es interpretable
        this.litrosVertidos= dep.litrosVertidos;        // Es interpretable
        
        // Actualización de los atributos estáticos (es interpretable)
        Deposito.litrosActualesTotales      += this.nivel;
        Deposito.litrosAlmacenadosTotales   += this.litrosAlmacenados;
        Deposito.litrosVertidosTotales      += this.litrosVertidos;
       
        if (this.estaLleno())
            ++Deposito.numDepositosLlenos;
        else if (this.estaVacio())
            ++Deposito.numDepositosVacios;
        
    }*/

    // MÉTODOS CONSULTORES (o "getters")
    // ---------------------------------
    /**
     * Obtiene la capacidad del depósito (en litros).
     * @return capacidad del depósito (en litros)
     */
    public double getCapacidad() {
        return this.CAPACIDAD;
    }

    /**
     * Obtiene el caudal de salida del grifo del depósito (en litros/segundo).
     * @return caudal de salida del grifo del depósito (en litros/segundo)
     */
    public double getCaudalSalida() {
        return this.CAUDAL_SALIDA;
    }

    /**
     * Indica si el depósito está completamente vacío.
     * @return true si el depósito está completamente vacío
     */
    public boolean estaVacio() {
        return (this.nivel == 0.0);
    }    

    /**
     * Indica si el depósito está completamente lleno.
     * @return true si el depósito está completamente lleno
     */
    public boolean estaLleno() {
        return (this.nivel == this.CAPACIDAD);
    }    
        
    /**
     * Obtiene el nivel actual del depósito (en litros).
     * @return nivel actual del depósito (en litros)
     */
    public double getNivelActual() {
        return this.nivel;
    }
        
    /**
     * Obtiene la cantidad de litros totales almacenados por el depósito desde 
     * su fabricación.
     * @return cantidad de litros totales almacenados por el depósito desde 
     * su fabricación
     */
    public double getVolumenIntroducidoDesdeCreacion() {
        return this.litrosAlmacenados;
    }
    
    /**
     * Obtiene la cantidad de litros totales vertidos por el depósito desde 
     * su fabricación.
     * @return cantidad de litros totales vertidos por el depósito desde 
     * su fabricación
     */
    public double getVolumenVertidoDesdeCreacion() {
        return this.litrosVertidos;
    }


    /**
     * Obtiene la cantidad de litros totales almacenados por todos los depósitos
     * en el momento actual.
     * @return cantidad de litros totales almacenados por todos los depósitos
     * en el momento actual
     */
    public static double getVolumenGlobalActual() {
        return Deposito.litrosActualesTotales;
    }

    /**
     * Obtiene la cantidad de litros totales almacenados por todos los depósitos
     * durante toda la historia de los depósitos hasta el momento actual.
     * @return cantidad de litros totales almacenados por todos los depósitos
     * durante toda la historia de los depósitos hasta el momento actual
     */
    public static double getVolumenGlobalIntroducido() {
        return Deposito.litrosAlmacenadosTotales;
    }

    
    /**
     * Obtiene la cantidad de litros totales vertidos por todos los depósitos
     * durante toda la historia de los depósitos hasta el momento actual.
     * @return cantidad de litros totales vertidos por todos los depósitos
     * durante toda la historia de los depósitos hasta el momento actual
     */
    public static double getVolumenGlobalVertido() {
        return Deposito.litrosVertidosTotales;
    }


    /**
     * Obtiene el número de depósitos completamente llenos en el momento actual.
     * @return número de depósitos completamente llenos en el momento actual
     */
    public static long getNumDepositosLlenos() {
        return Deposito.numDepositosLlenos;
    }

    /**
     * Obtiene el número de depósitos completamente vacíos en el momento actual.
     * @return número de depósitos completamente vacíos en el momento actual.
     */
    public static long getNumDepositosVacios() {
        return Deposito.numDepositosVacios;
    }

    
    
    // MÉTODOS DE ACCIÓN
    // -----------------  

    // Método llenar
    /**
     * Rellena el depósito una determinada cantidad de litros.
     * @param litros Cantidad de litros con los que se desea rellenar el depósito
     * @throws IllegalArgumentException si se produce un rebosamiento debido a que 
     * la cantidad de litros de llenado es superior a la que cabe en ese momento 
     * en el depósito
     */
    public void llenar (double litros) throws IllegalArgumentException {
        double llenadoReal= litros;
        double capacidadLibre= this.CAPACIDAD - this.nivel;
        double rebosamiento= 0.0;
        
        // Comprobación de rebosamiento
        if (litros>capacidadLibre) { // Se ha producido rebosamiento
            rebosamiento= litros - capacidadLibre;
            llenadoReal= capacidadLibre;
        }
        
        // Actualización de los atributos estáticos
        Deposito.litrosActualesTotales += llenadoReal;
        Deposito.litrosAlmacenadosTotales +=llenadoReal;
        if (!this.estaLleno() && litros>=capacidadLibre) 
            Deposito.numDepositosLlenos++;
        if (this.estaVacio() && litros>0.0) 
            Deposito.numDepositosVacios--;

        // Llenado del depósito en la cantidad apropiada
        this.nivel += llenadoReal; 

        // Actualizamos los históricos del objeto
        this.litrosAlmacenados += llenadoReal;
                
        // Lanzamiento de excepción en caso de rebosamiento
        if (rebosamiento>0.0)
            throw new IllegalArgumentException("Error: Depósito rebosado. Se ha desbordado en " + String.format("%5.2f litros: ", litros - llenadoReal));        
    }

    // Método abrirGrifo (sobrecargado)
    /**
     * Abre el grifo del depósito una determinada cantidad de segundos.
     * @param segundos Cantidad de segundos durante los que se desea abrir el grifo 
     * del depósito
     * @return cantidad de litros vertidos mientras el grifo ha estado abierto
     * @throws IllegalArgumentException si la cantidad de segundos es inválida (número negativo)
     */
    public double abrirGrifo (double segundos) throws IllegalArgumentException {
        double litrosParaVerter;
        double litrosVertidosReales;
        
        // Lanzamiento de excepción en caso de tiempo inválido
        if (segundos<0.0)
            throw new IllegalArgumentException("Error: Parámetro de tiempo inválido (tiempo negativo).");        

        // Calculamos la cantidad que va a ser vertida
        litrosParaVerter= segundos * this.CAUDAL_SALIDA;
        if (litrosParaVerter>this.nivel)
            litrosVertidosReales= this.nivel;
        else
            litrosVertidosReales= litrosParaVerter;

        // Actualizamos los atributos estáticos
        Deposito.litrosActualesTotales -= litrosVertidosReales;
        Deposito.litrosVertidosTotales += litrosVertidosReales;
        if (this.estaLleno() && litrosParaVerter>0.0) 
            Deposito.numDepositosLlenos--;
        if (!this.estaVacio() && litrosParaVerter>=this.nivel) 
            Deposito.numDepositosVacios++;
        
        // Actualizamos los históricos del objeto
        this.litrosVertidos += litrosVertidosReales;

        // Se disminuye el nivel
        this.nivel -= litrosVertidosReales;
        
        // Devolvemos los litros vertidos
        return litrosVertidosReales;
    }
    
    /**
     * Abre el grifo del depósito el tiempo transcurrido entre dos instantes.
     * @param inicio instante de apertura del grifo
     * @param fin instante de cierre del grifo
     * @return cantidad de litros vertidos mientras el grifo ha estado abierto
     * @throws IllegalArgumentException si el instante de inicio es posterior
     * al de fin, o si alguno de los instantes es null
     */
    public double abrirGrifo (LocalTime inicio, LocalTime fin) throws IllegalArgumentException {
        double segundos;
        
        if (inicio==null || fin==null)
            throw new IllegalArgumentException("Error: Parámetros de tiempo inválidos (null).");
            
        // Comprobamos que el inicio y el fin son coherentes
        if (inicio.isAfter(fin))
            throw new IllegalArgumentException("Error: Parámetros de tiempo inválidos (el instante de inicio es posterior al de fin).");        
            
        // Calculamos el número de segundos entre los instantes de inicio y fin
        segundos= inicio.until(fin, ChronoUnit.SECONDS);
        
        // Abrimos el grifo ese número de segundos
        return abrirGrifo (segundos);
        
    }

    // Método vaciar
    /**
     * Abre el grifo del depósito hasta que quede completamente vacío.
     * @return tiempo necesario para que el depósito se haya vaciado (segundos)
     */
    public double vaciar() {
        double segundos;
        
        // Cálculo del tiempo que tardará en vaciarse
        segundos= this.nivel / this.CAUDAL_SALIDA;
        
        // Actualizamos los históricos del objeto
        this.litrosVertidos += this.nivel;
        
        // Actualizamos los atributos estáticos
        Deposito.litrosActualesTotales -= this.nivel;
        Deposito.litrosVertidosTotales += this.nivel;
        if (this.estaLleno())
            Deposito.numDepositosLlenos--;
        if (!this.estaVacio())
            Deposito.numDepositosVacios++;
            
        // Ponemos a cero el nivel del depósito
        this.nivel= 0.0;
        
        // Devolvemos el número de segundos que ha tardado en vaciarse completamente
        return segundos;
    }
    
    // MÉTODOS PARA MOSTRAR INFORMACIÓN
    // --------------------------------
    // Método toString
    /**
     * Devuelve una cadena que representa el estado actual del depósito.
     * Esa cadena proporcionará la siguiente información.
     * <ol>
     * <li><strong>Capacidad del depósito</strong>.</li>
     * <li><strong>Nivel del depósito</strong> actual.</li>
     * <li><strong>Volumen almacenado histórico</strong> desde que se construyó el objeto.</li>
     * <li><strong>Volumen vertido histórico</strong> desde que se construyó el objeto.</li>
     * </ol>
     * <p><strong>El formato de salida</strong> será del siguiente tipo: </p>
     * <pre>Capacidad: XXX litros - NivelActual:  YYY litros - AlmacenadoTotal: ZZZ litros - VertidoTotal:     WWW litros</pre>
     * <p>donde XXX será la capacidad del depósito, expresada en litros con dos decimales; 
     * YYY será el nivel actual del depósito expresado en litros con dos decimales; 
     * ZZZ será el volumen total almacenado desde que se construyó el depósito, expresado en litros con dos decimales, 
     * y WWW el volumen total vertido desde que se construyó el depósito, expresado en litros con dos decimales.</p>
     * <p> Algunos ejemplos de este <code>String</code> de salida podrían ser:</p>
     * <pre>Capacidad: 196,35 litros - NivelActual:  99,00 litros - AlmacenadoTotal: 100,00 litros - VertidoTotal:     1,00 litros</pre>
     * <pre>Capacidad:  50,27 litros - NivelActual:   0,27 litros - AlmacenadoTotal: 100,27 litros - VertidoTotal:   100,00 litros</pre>
     * <pre>Capacidad: 100,53 litros - NivelActual:  38,00 litros - AlmacenadoTotal:  50,00 litros - VertidoTotal:    12,00 litros</pre>
     * <pre>Capacidad: 785,40 litros - NivelActual:   0,00 litros - AlmacenadoTotal:   0,00 litros - VertidoTotal:     0,00 litros</pre>
     * <pre>Capacidad: 196,35 litros - NivelActual:   0,00 litros - AlmacenadoTotal: 950,00 litros - VertidoTotal:   950,00 litros</pre>
     * @return <p>Cadena que representa el estado actual del depósito.</p>
     */
    @Override
    public String toString() {
        // La cadena se irá construyendo sobre un objeto StringBuilder
        // El uso de StringBuilder es más eficiente que el uso de Strings
        String sep1 = " - ";
        StringBuilder resultado = new StringBuilder();

        resultado.append("Capacidad: ");
        resultado.append(String.format("%6.2f litros", this.CAPACIDAD));
        resultado.append(sep1);
        
        resultado.append("NivelActual: ");
        resultado.append(String.format("%6.2f litros", this.nivel));
        resultado.append(sep1);

        resultado.append("AlmacenadoTotal: ");
        resultado.append(String.format("%6.2f litros", this.litrosAlmacenados));
        resultado.append(sep1);

        resultado.append("VertidoTotal: ");
        resultado.append(String.format("%6.2f litros", this.litrosVertidos));

        // Devolvemos la cadena construida*/
        return resultado.toString();
    }

    
    // MÉTODO DESTRUCTOR
    // -----------------
    // No había que implementarlo
/*    @Override
    protected void finalize () throws Throwable {
        super.finalize();
        // Actualizamos atributos estáticos al desaparecer este objeto
        Deposito.litrosActualesTotales -= this.nivel;
        if (this.estaLleno())
            Deposito.numDepositosLlenos--;
        else if (this.estaVacio())
            Deposito.numDepositosVacios--;
    }
*/   
    
    
}